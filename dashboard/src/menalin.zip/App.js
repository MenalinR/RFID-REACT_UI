// App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import { GiHamburgerMenu } from 'react-icons/gi';
import Home from './pages/Home';
import AddAdmin from './pages/AddAdmin';
import RemoveAdmin from './pages/RemoveAdmin';
import AddEmployee from './pages/AddEmployee';
import ScheduleMeet from './pages/ScheduleMeet';
import RemoveEmp from './pages/RemoveEmp';
import Log from './pages/Log';
import logo from './components/slt.png';
import './App.css';
import './components/rmv.css';
import './components/add.css';
import './components/remove.css';
import './components/ScheduleMeet.css';
import './components/addemp.css';
import './components/home.css';
import './components/log.css';




function App() {
  const [showNav, setshowNav] = useState(true);


 

  return (
    <Router>
      <header>
        <GiHamburgerMenu onClick={() => setshowNav(!showNav)} />
        <img src={logo} alt='Logo' className='logo'/>
        
      </header>
      <Navbar show={showNav} />
      <div className="main">
      <Routes>
      <Route path="/" element={<Navigate to="/Home" />} />
      <Route path="/Home" element={<Home />} />
        <Route path="/AddAdmin" element={<AddAdmin />} />
        <Route path="/RemoveAdmin" element={<RemoveAdmin />} />
        <Route path="/AddEmployee" element={<AddEmployee />} />
        <Route path="/ScheduleMeet" element={<ScheduleMeet />} />
        <Route path="/RemoveEmp" element={<RemoveEmp />} />
        <Route path="/Log" element={<Log />} />

        
      </Routes>
      </div>
    </Router>
  );
}

export default App;
