// RemoveAdmin.js

import React, { useState } from 'react';
import '../components/remove.css'; // Make sure to create this CSS file for styling

const RemoveAdmin = () => {
  // State to handle form data
  const [formData, setFormData] = useState({
    firstname: '',
    lastname: '',
    email: '',
    password: '',
  });

  // Handle form input changes
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    // Add your logic for form submission (removing admin) here
    // You can use the data from formData
    console.log('Remove admin logic goes here:', formData);
  };

  return (
    <div  className='container'>
      <h4> Remove Admin </h4><br></br>
      <form onSubmit={handleSubmit} className='frm'>
        <label htmlFor="adminname">Admin name: </label>
        <input
          type="text"
          name="adminname"
          value={formData.adminname}
          onChange={handleInputChange}
          required
        />
        
        <br />
        <label htmlFor="password">Password: </label>
        <input
          type="password"
          name="password"
          value={formData.password}
          onChange={handleInputChange}
          required
        />
        <br /><br></br>
        <div >
          <button type="submit">Add</button>
        </div>
      </form>
    </div>
    
  );
};

export default RemoveAdmin;
