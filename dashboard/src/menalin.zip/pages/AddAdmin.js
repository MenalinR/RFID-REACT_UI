import React, { useState } from 'react';
import '../components/add.css';

const AddAdmin = () => {
  const [permissions, setPermissions] = useState([]);

  const handleCheckboxChange = (e) => {
    const { value } = e.target;

    // Check if the permission is already in the state
    if (permissions.includes(value)) {
      // Remove the permission if it exists
      setPermissions((prevPermissions) =>
        prevPermissions.filter((perm) => perm !== value)
      );
    } else {
      // Add the permission if it doesn't exist
      setPermissions((prevPermissions) => [...prevPermissions, value]);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add your form submission logic here with the permissions state
    console.log('Admin Name:', e.target.elements.adminName.value);
    console.log('Password:', e.target.elements.password.value);
    console.log('Permissions:', permissions);
  };

  return (
    <section className="container" style={{ maxHeight: '1000px' }}>
      <h4 className="add">Add Admin:</h4>
      <hr />
      <form onSubmit={handleSubmit} className="form"  >
        <div className="input-box">
          <label>Admin Name::</label>
          <input type="text" name="adminName" placeholder="Enter admin name" required />
        </div>
        <div className="input-box">
          <label>Password:</label>
          <input type="password" name="password" placeholder="Enter password" required />
        </div>
        <div className="input-box">
          <label>Permissions:</label>
          <div className="checkbox-group">
            <label>
             
              
              Add Employee:
            </label>
         
              <input
                type="checkbox"
                value="create"
                onChange={handleCheckboxChange}
                checked={permissions.includes('create')}
              />
              
              <label>
              Remove Employee:
            </label>
            <input
                type="checkbox"
                value="read"
                onChange={handleCheckboxChange}
                checked={permissions.includes('read')}
              />
            <label>
            schedule Meetings:
            </label>
              <input
                type="checkbox"
                value="update"
                onChange={handleCheckboxChange}
                checked={permissions.includes('update')}
              />
              
            <label>
            Handle Log System:
            </label>
              <input
                type="checkbox"
                value="delete"
                onChange={handleCheckboxChange}
                checked={permissions.includes('delete')}
              />
              
          </div>
        </div>
        <div >
          <button type="submit">Add</button>
        </div>
      </form>
    </section>
  );
};

export default AddAdmin;
