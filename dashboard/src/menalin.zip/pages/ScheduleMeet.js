import React, { useState } from 'react';
import '../components/ScheduleMeet.css';

const ScheduleMeet = () => {
  const [selectedOptions, setSelectedOptions] = useState([]);
 

  const handleOptionChange = (event) => {
    const selectedIDs = Array.from(event.target.selectedOptions, (option) => option.value);
    setSelectedOptions(selectedIDs);

    // Fetch employee details based on the selected IDs
    // Replace the following with your actual fetch logic
    // Example API call: fetch(`your-api-url/${selectedIDs.join(',')}`)
    //   .then(response => response.json())
    //   .then(data => setEmployeeDetails(data));

    // Mock data for demonstration purposes
 
  };

  return (
    <section className="container">
      <h4>Meeting Schedule</h4>
      <hr></hr>
      <form action="#" className="form">
        <div className="input-box">
          <label>Meeting Topic</label>
          <input type="text" placeholder="Enter the topic of the meeting" required />
        </div>
        <div className="input-box">
          <div>
            <label htmlFor="listBox">Participants:</label><br></br>
            <select
              id="listBox"
              multiple
              value={selectedOptions}
              onChange={handleOptionChange}
            >
              <option value="Emp1">Emp1</option>
              <option value="Emp2">Emp2</option>
              <option value="Emp3">Emp3</option>
              <option value="Emp3">Emp4</option>
              <option value="Emp3">Emp5</option>
            </select>
            <p>Selected: {selectedOptions.join(', ')}</p>
          </div>
        </div>
       
        <div className="input-box">
          <label>Date</label>
          <input type="date" id="meetingDate" name="meetingDate" required />
        </div>
        <div className="input-box">
          <br></br>
          <label>Meeting Time</label>
          <br></br>
          <div className="column">
            <div className="time">
            <label htmlFor="startTime">Start Time:</label>
            <input type="time" id="startTime" name="startTime" />
            <label htmlFor="endTime">End Time:</label>
            <input type="time" id="endTime" name="endTime" />
            </div>
            <label htmlFor="duration">Duration (minutes):</label>
            <input type="text" id="duration" name="duration" />
          </div>
        </div>
        <div>
          <button type="submit">Schedule</button>
        </div>
      </form>
    </section>
  );
};

export default ScheduleMeet;
