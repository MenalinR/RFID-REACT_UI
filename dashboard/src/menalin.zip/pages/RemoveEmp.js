import React, { useState } from 'react';
import '../components/rmv.css';

const RemoveEmp = () => {
  const [selectedOption, setSelectedOption] = useState('');

  const handleOptionChange = (e) => {
    setSelectedOption(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add your logic for removing an employee here
    console.log(`Removing employee with ID: ${selectedOption}`);
  };

  return (
    <div className='up'>
    <div className="container" id="remove">
        <h4>Remove Employee</h4><hr></hr>
      <form className="form" onSubmit={handleSubmit}>
      
          <label htmlFor="listBox">Select an Employee ID:</label><br></br>
          <select id="listBox" value={selectedOption} onChange={handleOptionChange}>
            <option value="">Select...</option>
            <option value="option1">Emp1</option>
            <option value="option2">Emp2</option>
            <option value="option3">Emp3</option>
          </select>
          <p>Selected : {selectedOption}</p>
        

        <div >
          <button type="submit">Remove</button>
        </div>
      </form>
      </div>
    </div>
   
  );
};

export default RemoveEmp;
