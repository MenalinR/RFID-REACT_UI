// AddEmployee.js
import React from 'react';
import '../components/addemp.css';

const AddEmployee = () => {
  const handleSubmit = (e) => {
    e.preventDefault();
    // Add your form submission logic here
  };

  return (
    <div>
      <form onSubmit={handleSubmit} style={{ border: '1px solid #ccc' }}>
        <div className="container">
          <p>Create an employee</p>
          <hr />
          <div className="input-box">
          <label ><b>Employee Name</b></label>
          <input type="text" placeholder="Employee Name" name="employeeName" required />
          </div>
          <div className="input-box">
          <label ><b>Employee ID</b></label>
          <input type="text" placeholder="Enter ID" name="employeeID" required />
          </div>
          
          <div className="input-box">
          <label ><b>Job Role</b></label>
          <input type="text" placeholder="Enter Job Role" name="jobRole" required />
          </div>

          <div className="input-box">
          <label ><b>Department</b></label>
          <input type="text" placeholder="Enter Department" name="department" required />
          </div>
          
          <div className="clearfix">
            <button type="submit" className="signupbtn">
              Add
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default AddEmployee;
